# Video-Maker — kostenlos, lokal, mit Webseite

Thema eingeben → KI erstellt Skript, Bilder und Video. **$0 laufende Kosten** — alles läuft auf deinem eigenen Rechner, keine API-Keys nötig.

## Setup (einmalig)

```bash
# 1. FFmpeg installieren (falls noch nicht vorhanden)
# macOS:   brew install ffmpeg
# Ubuntu:  sudo apt install ffmpeg
# Windows: https://ffmpeg.org/download.html

# 2. Python-Pakete installieren
pip install -r requirements.txt
```

Das war's — **keine API-Keys, kein Account nötig.**

## Nutzung — als Webseite (empfohlen)

```bash
python app.py
```

Öffnet automatisch `http://localhost:5000` im Browser. Thema eingeben, Knopf klicken, warten, Video erscheint direkt auf der Seite.

## Nutzung — als Terminal-Befehl (Alternative)

```bash
python make_video.py "5 Tipps für besseren Schlaf"
```

## Wichtig zu wissen: Geschwindigkeit hängt von deiner Hardware ab

| Hardware | Geschwindigkeit |
|---|---|
| Mit Gaming-GPU (8GB+ VRAM) | ~1-3 Minuten pro Video |
| Ohne GPU (nur CPU) | Funktioniert auch, aber deutlich langsamer — mehrere Minuten bis Stunden, je nach Rechner |

**Erster Start dauert länger:** Die KI-Modelle (~10GB) werden einmalig automatisch herunterladen. Das passiert nur beim allerersten Mal.

## Sprachausgabe aktivieren (optional)

Ohne weiteres Setup bleibt das Video stumm (Bild + eingeblendeter Text, keine Stimme) — Musik kannst du z.B. in CapCut/InShot selbst hinzufügen.

Für echte Sprachausgabe:

```bash
pip install piper-tts
python -m piper.download_voices de_DE-thorsten-medium
```

Dann in `.env` (kopiert von `.env.example`) den Pfad zur heruntergeladenen `.onnx`-Datei eintragen und auf der Webseite die Checkbox "Mit Sprachausgabe" aktivieren.

## Was im Hintergrund passiert

1. **Qwen2.5-1.5B** (kleines lokales Sprachmodell) schreibt das Skript
2. **FLUX.1-schnell** generiert ein Bild pro Szene
3. **Piper** spricht den Text (falls aktiviert)
4. **FFmpeg** baut Ken-Burns-Zoom + Caption + Ton zu einem fertigen Video zusammen

Alle Modelle laufen direkt in Python — kein Ollama, kein separater Server, keine Cloud.

## Auf GitHub hochladen

```bash
git init
git add .
git commit -m "Video Maker"
git remote add origin https://github.com/<dein-username>/<dein-repo>.git
git push -u origin main
```

Die `.gitignore` sorgt dafür, dass generierte Videos und eine eventuelle `.env` nicht mitgeladen werden.

**Wichtig:** GitHub speichert nur den Code. Zum Nutzen musst du das Repo auf deinen Rechner herunterladen (`git clone ...`) und dort `python app.py` ausführen — eine Webseite auf GitHub selbst kann keine KI-Modelle ausführen.

## Anpassen

- **Caption-Stil** → `video_pipeline.py`, Funktion `build_scene_clip()`
- **Anderes/größeres Sprachmodell** → `video_pipeline.py`, `_get_llm()`, z.B. `Qwen/Qwen2.5-7B-Instruct` (braucht mehr VRAM, bessere Texte)
- **Bildstil** → Prompt in `generate_script()` anpassen, z.B. "im Comic-Stil"

## Wenn etwas nicht funktioniert

- **Sehr langsam / hängt** → wahrscheinlich läuft alles auf CPU (keine GPU erkannt) — normal, aber langsam. Prüfen: `python -c "import torch; print(torch.cuda.is_available())"`
- **"CUDA out of memory"** → GPU-VRAM reicht nicht — `--scenes` reduzieren oder `GEN_WIDTH`/`GEN_HEIGHT` in `video_pipeline.py` verkleinern
- **Schrift-Fehler bei Caption** → `DejaVu Sans Bold` nicht installiert; in `build_scene_clip()` den `font=`-Teil aus `drawtext` entfernen
