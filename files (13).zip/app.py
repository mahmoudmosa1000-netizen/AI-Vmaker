#!/usr/bin/env python3
# ============================================================
#  app.py
#  Die Webseite: Eingabefeld + Knopf → Video. Läuft komplett
#  auf deinem eigenen Rechner (http://localhost:5000) —
#  nichts wird ins Internet hochgeladen, keine laufenden Kosten.
#
#  Starten:  python app.py
#  Öffnen:   http://localhost:5000
# ============================================================

import os
import uuid
import threading
import webbrowser
from pathlib import Path

from flask import Flask, request, jsonify, render_template_string, send_from_directory

from video_pipeline import generate_video

app = Flask(__name__)

OUTPUT_DIR = Path("generated_videos")
OUTPUT_DIR.mkdir(exist_ok=True)

# Einfacher In-Memory-Job-Speicher — reicht für ein Ein-Personen-Tool,
# das lokal läuft. Bei einem Neustart der Webseite sind alte Jobs weg
# (die fertigen Videos in generated_videos/ bleiben aber erhalten).
JOBS: dict[str, dict] = {}


PAGE = """
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Video-Maker</title>
<style>
  :root { --bg:#0e0d0b; --surface:#17150f; --border:#2a2620; --text:#f3efe6; --muted:#9a9382; --accent:#ff7a30; }
  * { box-sizing: border-box; }
  body { background:var(--bg); color:var(--text); font-family:-apple-system,Inter,sans-serif;
         display:flex; justify-content:center; padding:60px 20px; margin:0; }
  .card { max-width:480px; width:100%; }
  h1 { font-size:22px; margin-bottom:6px; }
  p.sub { color:var(--muted); font-size:14px; margin-bottom:28px; }
  label { font-size:13px; color:var(--muted); display:block; margin-bottom:6px; margin-top:18px; }
  input[type=text], input[type=number] {
    width:100%; padding:12px 14px; border-radius:8px; border:1px solid var(--border);
    background:var(--surface); color:var(--text); font-size:14px; outline:none;
  }
  input:focus { border-color: var(--accent); }
  .row { display:flex; gap:16px; }
  .row > div { flex:1; }
  .checkbox-row { display:flex; align-items:center; gap:8px; margin-top:16px; }
  .checkbox-row label { margin:0; }
  button {
    width:100%; margin-top:26px; padding:13px; border-radius:8px; border:none;
    background:var(--accent); color:#1a0f05; font-weight:600; font-size:14px; cursor:pointer;
  }
  button:disabled { opacity:0.5; cursor:not-allowed; }
  #status { margin-top:20px; font-size:13px; color:var(--muted); white-space:pre-wrap;
            font-family:monospace; min-height:20px; }
  #result { margin-top:20px; }
  video { width:100%; border-radius:10px; border:1px solid var(--border); }
  .note { margin-top:30px; font-size:11px; color:var(--muted); line-height:1.6; }
</style>
</head>
<body>
<div class="card">
  <h1>🎬 Video-Maker</h1>
  <p class="sub">Thema eingeben → KI erstellt Bilder, Text und Video. Komplett lokal, $0 Kosten.</p>

  <label>Worum geht's im Video?</label>
  <input type="text" id="topic" placeholder="z.B. 5 Tipps für besseren Schlaf" />

  <div class="row">
    <div>
      <label>Anzahl Szenen</label>
      <input type="number" id="scenes" value="5" min="2" max="10" />
    </div>
  </div>

  <div class="checkbox-row">
    <input type="checkbox" id="voice" />
    <label for="voice" style="margin:0">Mit Sprachausgabe (braucht Piper-Setup, siehe README)</label>
  </div>

  <button id="submitBtn" onclick="startGeneration()">Video erstellen</button>

  <div id="status"></div>
  <div id="result"></div>

  <p class="note">
    Erster Start dauert länger (Modelle werden heruntergeladen, einmalig ~10GB).
    Danach: mit GPU ca. 1-3 Minuten pro Video, ohne GPU deutlich langsamer (CPU-Modus).
  </p>
</div>

<script>
async function startGeneration() {
  const topic = document.getElementById('topic').value.trim();
  if (!topic) { alert('Bitte ein Thema eingeben'); return; }

  const scenes = document.getElementById('scenes').value;
  const voice = document.getElementById('voice').checked;
  const btn = document.getElementById('submitBtn');
  const statusEl = document.getElementById('status');
  const resultEl = document.getElementById('result');

  btn.disabled = true;
  resultEl.innerHTML = '';
  statusEl.textContent = 'Starte...';

  const res = await fetch('/generate', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({topic, scenes: parseInt(scenes), voice}),
  });
  const {job_id} = await res.json();

  const poll = setInterval(async () => {
    const r = await fetch(`/status/${job_id}`);
    const data = await r.json();
    statusEl.textContent = data.progress || '...';

    if (data.status === 'done') {
      clearInterval(poll);
      btn.disabled = false;
      resultEl.innerHTML = `<video controls src="/videos/${data.filename}"></video>`;
    } else if (data.status === 'error') {
      clearInterval(poll);
      btn.disabled = false;
      statusEl.textContent = '❌ Fehler: ' + data.progress;
    }
  }, 2000);
}
</script>
</body>
</html>
"""


@app.route("/")
def index():
    return render_template_string(PAGE)


@app.route("/generate", methods=["POST"])
def generate():
    data = request.get_json()
    topic = data.get("topic", "").strip()
    num_scenes = max(2, min(int(data.get("scenes", 5)), 10))
    with_voice = bool(data.get("voice", False))

    if not topic:
        return jsonify({"error": "Thema fehlt"}), 400

    job_id = str(uuid.uuid4())
    filename = f"{job_id}.mp4"
    JOBS[job_id] = {"status": "running", "progress": "Wird gestartet...", "filename": filename}

    def run():
        try:
            def on_progress(msg):
                JOBS[job_id]["progress"] = msg

            output_path = str(OUTPUT_DIR / filename)
            generate_video(topic, num_scenes, output_path, with_voice, on_progress)
            JOBS[job_id]["status"] = "done"
        except Exception as e:
            JOBS[job_id]["status"] = "error"
            JOBS[job_id]["progress"] = str(e)

    threading.Thread(target=run, daemon=True).start()
    return jsonify({"job_id": job_id})


@app.route("/status/<job_id>")
def status(job_id):
    job = JOBS.get(job_id)
    if not job:
        return jsonify({"status": "error", "progress": "Job nicht gefunden"}), 404
    return jsonify(job)


@app.route("/videos/<filename>")
def serve_video(filename):
    return send_from_directory(OUTPUT_DIR, filename)


if __name__ == "__main__":
    port = 5000
    threading.Timer(1.5, lambda: webbrowser.open(f"http://localhost:{port}")).start()
    print(f"\n🌐 Öffne http://localhost:{port} im Browser (oder klicke den Link)\n")
    app.run(host="0.0.0.0", port=port, debug=False)
