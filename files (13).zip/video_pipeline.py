#!/usr/bin/env python3
# ============================================================
#  video_pipeline.py
#  Komplett KOSTENLOSE Video-Pipeline — alles läuft lokal:
#    - Skript:  Qwen2.5-1.5B-Instruct (kleines lokales LLM)
#    - Bilder:  FLUX.1-schnell (läuft auf GPU ODER CPU, GPU = schneller)
#    - Stimme:  Piper TTS (optional, überspringt sich selbst wenn nicht installiert)
#    - Video:   FFmpeg (Ken-Burns-Zoom + Caption-Einblendung)
#
#  KEINE API-Keys, KEINE laufenden Kosten. Wird sowohl von
#  app.py (Webseite) als auch make_video.py (Terminal) genutzt.
# ============================================================

import os
import json
import subprocess
import tempfile
from pathlib import Path

import torch
from PIL import Image

VIDEO_WIDTH = 1080
VIDEO_HEIGHT = 1920  # 9:16 — TikTok/Reels/Shorts

# Generierungs-Auflösung etwas kleiner als Zielauflösung — spart Zeit,
# FFmpeg skaliert beim Ken-Burns-Schritt ohnehin wieder hoch.
GEN_WIDTH = 768
GEN_HEIGHT = 1344

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# ── Lazy-geladene Modelle (nur beim ersten Gebrauch, dann gecacht) ──
_llm = None
_llm_tokenizer = None
_flux_pipe = None


def _log(msg: str, progress_callback=None):
    print(msg)
    if progress_callback:
        progress_callback(msg)


# ============================================================
#  SCHRITT 1: Skript schreiben — Qwen2.5-1.5B-Instruct (lokal)
# ============================================================

def _get_llm():
    global _llm, _llm_tokenizer
    if _llm is None:
        from transformers import AutoModelForCausalLM, AutoTokenizer
        model_id = "Qwen/Qwen2.5-1.5B-Instruct"
        _llm_tokenizer = AutoTokenizer.from_pretrained(model_id)
        _llm = AutoModelForCausalLM.from_pretrained(
            model_id,
            torch_dtype=torch.float16 if DEVICE == "cuda" else torch.float32,
        ).to(DEVICE)
    return _llm, _llm_tokenizer


def generate_script(topic: str, num_scenes: int, progress_callback=None) -> list[dict]:
    _log(f"✍️  Schreibe Skript für: '{topic}' ({num_scenes} Szenen)...", progress_callback)

    model, tokenizer = _get_llm()

    system_prompt = (
        "Du bist ein Social-Media-Texter. Antworte NUR mit validem JSON, "
        "ohne Markdown-Backticks, ohne Erklärungen."
    )
    user_prompt = f"""Erstelle ein kurzes Skript für ein vertikales Social-Media-Video.

Thema: "{topic}"
Anzahl Szenen: {num_scenes}

Jede Szene braucht:
- caption: Kurzer Text fürs Bild (max. 8 Wörter)
- narration: Gesprochener Satz (1-2 Sätze)
- image_prompt: Englische Bildbeschreibung für KI-Bildgenerierung

JSON-Format:
{{"title": "...", "scenes": [{{"caption": "...", "narration": "...", "image_prompt": "..."}}]}}"""

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]
    text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = tokenizer(text, return_tensors="pt").to(DEVICE)

    with torch.no_grad():
        output_ids = model.generate(
            **inputs, max_new_tokens=1024, temperature=0.7,
            do_sample=True, pad_token_id=tokenizer.eos_token_id,
        )
    raw = tokenizer.decode(output_ids[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)

    data = _parse_json_with_fallback(raw, topic, num_scenes)
    _log(f"✅ Skript fertig: \"{data['title']}\" ({len(data['scenes'])} Szenen)", progress_callback)
    return data["scenes"]


def _parse_json_with_fallback(raw: str, topic: str, num_scenes: int) -> dict:
    cleaned = raw.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("```")[1].removeprefix("json").strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        # Kleines lokales Modell hält das JSON-Format nicht immer exakt ein —
        # einfacher Fallback, damit das Video trotzdem entsteht.
        return {
            "title": topic,
            "scenes": [
                {"caption": f"{topic} – Teil {i+1}", "narration": "", "image_prompt": topic}
                for i in range(num_scenes)
            ],
        }


# ============================================================
#  SCHRITT 2: Bild pro Szene — FLUX.1-schnell (lokal, GPU/CPU)
# ============================================================

def _get_flux():
    global _flux_pipe
    if _flux_pipe is None:
        from diffusers import FluxPipeline
        _flux_pipe = FluxPipeline.from_pretrained(
            "black-forest-labs/FLUX.1-schnell",
            torch_dtype=torch.bfloat16 if DEVICE == "cuda" else torch.float32,
        )
        if DEVICE == "cuda":
            _flux_pipe.enable_model_cpu_offload()
        else:
            _flux_pipe = _flux_pipe.to(DEVICE)
    return _flux_pipe


def generate_image(prompt: str, output_path: str, progress_callback=None):
    _log(f"   🎨 Bild: {prompt[:60]}...", progress_callback)
    pipe = _get_flux()
    with torch.inference_mode():
        result = pipe(
            prompt=prompt, width=GEN_WIDTH, height=GEN_HEIGHT,
            num_inference_steps=4, guidance_scale=0.0,
        )
    result.images[0].save(output_path, "PNG")


# ============================================================
#  SCHRITT 3: Sprachausgabe — Piper TTS (optional, lokal)
# ============================================================

def generate_voiceover(text: str, output_path: str, progress_callback=None) -> bool:
    """Gibt False zurück (Video bleibt stumm), wenn Piper nicht eingerichtet ist —
    bricht NICHT ab, damit das Video trotzdem fertig wird."""
    voice_model = os.getenv("PIPER_VOICE_MODEL", "")
    if not voice_model or not os.path.exists(voice_model):
        return False

    try:
        from piper import PiperVoice
        _log(f"   🔊 Stimme: {text[:50]}...", progress_callback)
        voice = PiperVoice.load(voice_model)
        with open(output_path, "wb") as f:
            voice.synthesize(text, f)
        return True
    except Exception as e:
        _log(f"   ⚠ Sprachausgabe übersprungen ({e})", progress_callback)
        return False


# ============================================================
#  SCHRITT 4: Video zusammenbauen — FFmpeg
# ============================================================

def get_audio_duration(audio_path: str) -> float:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", audio_path],
        capture_output=True, text=True,
    )
    return float(result.stdout.strip())


def build_scene_clip(image_path: str, audio_path: str | None, caption: str,
                      duration: float, output_path: str):
    fps = 30
    total_frames = int(duration * fps)

    safe_caption = caption.replace("'", "\u2019").replace(":", "\\:")
    drawtext = (
        f"drawtext=text='{safe_caption}':fontcolor=white:fontsize=64:"
        f"borderw=4:bordercolor=black:font='DejaVu Sans Bold':"
        f"x=(w-text_w)/2:y=h*0.72:line_spacing=10"
    )
    zoompan = f"zoom='min(zoom+0.0012,1.12)':d={total_frames}:s={VIDEO_WIDTH}x{VIDEO_HEIGHT}:fps={fps}"

    cmd = ["ffmpeg", "-y", "-loop", "1", "-i", image_path]
    if audio_path:
        cmd += ["-i", audio_path]
    cmd += [
        "-vf", f"scale={VIDEO_WIDTH*2}:{VIDEO_HEIGHT*2},zoompan={zoompan},{drawtext}",
        "-t", str(duration), "-c:v", "libx264", "-pix_fmt", "yuv420p",
    ]
    if audio_path:
        cmd += ["-c:a", "aac", "-shortest"]
    cmd += [output_path]

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"FFmpeg-Fehler bei Szenen-Clip: {result.stderr[-500:]}")


def concat_clips(clip_paths: list[str], output_path: str):
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        for p in clip_paths:
            f.write(f"file '{os.path.abspath(p)}'\n")
        list_file = f.name

    cmd = ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", list_file, "-c", "copy", output_path]
    result = subprocess.run(cmd, capture_output=True, text=True)
    os.unlink(list_file)
    if result.returncode != 0:
        raise RuntimeError(f"FFmpeg-Fehler beim Zusammenfügen: {result.stderr[-500:]}")


# ============================================================
#  ORCHESTRIERUNG — wird von app.py UND make_video.py genutzt
# ============================================================

def generate_video(topic: str, num_scenes: int, output_path: str,
                    with_voice: bool = False, progress_callback=None) -> str:
    with tempfile.TemporaryDirectory() as tmp:
        scenes = generate_script(topic, num_scenes, progress_callback)

        clip_paths = []
        for i, scene in enumerate(scenes):
            _log(f"📍 Szene {i+1}/{len(scenes)}: {scene['caption']}", progress_callback)

            image_path = os.path.join(tmp, f"scene_{i}.png")
            generate_image(scene["image_prompt"], image_path, progress_callback)

            audio_path = os.path.join(tmp, f"scene_{i}.wav")
            has_audio = with_voice and generate_voiceover(scene["narration"], audio_path, progress_callback)

            duration = get_audio_duration(audio_path) + 0.5 if has_audio else 3.0

            clip_path = os.path.join(tmp, f"clip_{i}.mp4")
            build_scene_clip(
                image_path, audio_path if has_audio else None,
                scene["caption"], duration, clip_path,
            )
            clip_paths.append(clip_path)

        _log(f"🎬 Füge {len(clip_paths)} Szenen zusammen...", progress_callback)
        concat_clips(clip_paths, output_path)

    _log(f"✅ Fertig: {output_path}", progress_callback)
    return output_path
