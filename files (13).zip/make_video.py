#!/usr/bin/env python3
# ============================================================
#  make_video.py
#  Terminal-Variante — nutzt dieselbe kostenlose, lokale
#  Pipeline wie app.py (Webseite). Kein API-Key nötig.
#
#  Nutzung:
#    python make_video.py "5 Tipps für besseren Schlaf"
# ============================================================

import argparse
from video_pipeline import generate_video


def main():
    parser = argparse.ArgumentParser(description="Erstellt ein TikTok/Reels-Video aus einer Idee — kostenlos, lokal.")
    parser.add_argument("topic", help="Worum geht's im Video?")
    parser.add_argument("--scenes", type=int, default=5, help="Anzahl Szenen (Standard: 5)")
    parser.add_argument("--output", default="output.mp4", help="Ausgabedatei (Standard: output.mp4)")
    parser.add_argument("--voice", action="store_true", help="Sprachausgabe aktivieren (braucht Piper-Setup)")
    args = parser.parse_args()

    generate_video(args.topic, args.scenes, args.output, args.voice, progress_callback=print)

    print(f"\n✅ Fertig! Video gespeichert: {args.output}")


if __name__ == "__main__":
    main()
